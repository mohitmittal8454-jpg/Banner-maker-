
import React, { useState, useRef, useEffect } from 'react';
import { Layout } from './components/Layout';
import { AppStatus, GenerationResult } from './types';
import { generateThumbnailImage, generateMetadata, generateStrategyInsight } from './services/geminiService';

const App: React.FC = () => {
  const [status, setStatus] = useState<AppStatus>(AppStatus.IDLE);
  const [videoTitle, setVideoTitle] = useState('');
  const [vibe, setVibe] = useState('MrBeast Intensity');
  
  // Image States
  const [originalImage, setOriginalImage] = useState<string | null>(null);
  const [headshot, setHeadshot] = useState<string | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  
  // Edit Adjustment States
  const [brightness, setBrightness] = useState(100);
  const [contrast, setContrast] = useState(100);
  
  const [result, setResult] = useState<GenerationResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [previewMode, setPreviewMode] = useState<'canvas' | 'feed'>('canvas');
  
  // Heatmap Interaction State
  const [showHeatmap, setShowHeatmap] = useState(false);
  const [heatmapIntensity, setHeatmapIntensity] = useState(60);
  const [heatmapPreset, setHeatmapPreset] = useState<'classic' | 'thermal' | 'glitch'>('classic');
  
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [copyStatus, setCopyStatus] = useState<string | null>(null);
  const [simViews, setSimViews] = useState(0);
  const [showConfetti, setShowConfetti] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const editCanvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (copyStatus) {
      const timer = setTimeout(() => setCopyStatus(null), 2000);
      return () => clearTimeout(timer);
    }
  }, [copyStatus]);

  useEffect(() => {
    if (result) {
      setShowConfetti(true);
      const timer = setTimeout(() => setShowConfetti(false), 5000);
      
      const interval = setInterval(() => {
        setSimViews(prev => prev + Math.floor(Math.random() * 50));
      }, 2000);
      return () => {
        clearInterval(interval);
        clearTimeout(timer);
      };
    } else {
      setSimViews(0);
    }
  }, [result]);

  // Apply edits in real-time when sliders move
  useEffect(() => {
    if (originalImage && isEditing) {
      const img = new Image();
      img.onload = () => {
        if (editCanvasRef.current) {
          const ctx = editCanvasRef.current.getContext('2d');
          if (ctx) {
            editCanvasRef.current.width = img.width;
            editCanvasRef.current.height = img.height;
            ctx.filter = `brightness(${brightness}%) contrast(${contrast}%)`;
            ctx.drawImage(img, 0, 0);
            setHeadshot(editCanvasRef.current.toDataURL('image/jpeg', 0.9));
          }
        }
      };
      img.src = originalImage;
    }
  }, [brightness, contrast, originalImage, isEditing]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        setOriginalImage(base64);
        setHeadshot(base64);
        setBrightness(100);
        setContrast(100);
        setIsEditing(true);
      };
      reader.readAsDataURL(file);
    }
  };

  const startCamera = async () => {
    try {
      setIsCameraActive(true);
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      setError("Unable to access camera. Please check permissions.");
      setIsCameraActive(false);
    }
  };

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const context = canvasRef.current.getContext('2d');
      if (context) {
        canvasRef.current.width = videoRef.current.videoWidth;
        canvasRef.current.height = videoRef.current.videoHeight;
        context.drawImage(videoRef.current, 0, 0);
        const dataUrl = canvasRef.current.toDataURL('image/jpeg');
        setOriginalImage(dataUrl);
        setHeadshot(dataUrl);
        setBrightness(100);
        setContrast(100);
        setIsEditing(true);
        stopCamera();
      }
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    setIsCameraActive(false);
  };

  const handleStartGeneration = async () => {
    if (!videoTitle || !headshot) {
      setError("Please provide both a video title and a headshot.");
      return;
    }

    try {
      setError(null);
      setResult(null);
      setIsEditing(false); // Hide editor during generation
      
      setStatus(AppStatus.GENERATING_IMAGE);
      const imageUrl = await generateThumbnailImage(videoTitle, headshot, vibe);
      
      setStatus(AppStatus.GENERATING_METADATA);
      const metadata = await generateMetadata(videoTitle, imageUrl);

      setStatus(AppStatus.GENERATING_STRATEGY);
      const strategy = await generateStrategyInsight(videoTitle);
      
      setResult({ imageUrl, metadata, strategy });
      setStatus(AppStatus.SUCCESS);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "An unexpected error occurred.");
      setStatus(AppStatus.ERROR);
    }
  };

  const handleDownload = () => {
    if (result?.imageUrl) {
      const link = document.createElement('a');
      link.href = result.imageUrl;
      link.download = `viral-thumbnail-${Date.now()}.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopyStatus(id);
  };

  const reset = () => {
    setStatus(AppStatus.IDLE);
    setResult(null);
    setError(null);
    setHeadshot(null);
    setOriginalImage(null);
    setIsEditing(false);
  };

  const vibes = ["MrBeast Intensity", "Dark Documentary", "Luxury/Clean", "Cyberpunk", "Minimalist Guru"];

  const getHeatmapStyles = (baseColor: string) => {
    const opacity = (heatmapIntensity / 100).toFixed(2);
    const blur = (heatmapIntensity / 2).toFixed(0);
    return {
      background: baseColor,
      filter: `blur(${blur}px)`,
      opacity: opacity,
    };
  };

  const getHeatmapBaseColor = (zone: 'core' | 'secondary' | 'edge') => {
    switch (heatmapPreset) {
      case 'thermal':
        return zone === 'core' ? '#ffffff' : zone === 'secondary' ? '#fde047' : '#ef4444';
      case 'glitch':
        return zone === 'core' ? '#22d3ee' : zone === 'secondary' ? '#a855f7' : '#ec4899';
      default: // classic
        return zone === 'core' ? '#ef4444' : zone === 'secondary' ? '#f97316' : '#eab308';
    }
  };

  return (
    <Layout>
      {/* Confetti Effect Overlay */}
      {showConfetti && (
        <div className="fixed inset-0 pointer-events-none z-[100] flex items-center justify-center overflow-hidden">
          {Array.from({ length: 50 }).map((_, i) => (
            <div 
              key={i} 
              className="absolute w-2 h-2 bg-blue-500 rounded-full animate-bounce"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                backgroundColor: ['#3b82f6', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981'][Math.floor(Math.random() * 5)],
                animationDuration: `${Math.random() * 3 + 2}s`,
                animationDelay: `${Math.random() * 2}s`,
                opacity: 0.7
              }}
            ></div>
          ))}
        </div>
      )}

      <div className="text-center mb-12 space-y-4 max-w-4xl mx-auto">
        <h2 className="text-5xl md:text-7xl font-extrabold tracking-tighter leading-tight">
          Viral <span className="gradient-text">Engine</span> AI
        </h2>
        <p className="text-slate-400 text-xl font-light">
          Accelerate your growth with AI-driven visuals and data-backed strategy.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        {/* Left Control Panel */}
        <div className="lg:col-span-4 space-y-6">
          <div className="glass-effect rounded-3xl p-8 space-y-8 border-white/5 shadow-2xl">
            <div className="space-y-1">
              <h2 className="text-2xl font-bold flex items-center gap-3">
                <i className="fa-solid fa-sliders text-blue-500 text-lg"></i>
                Creative Studio
              </h2>
              <p className="text-slate-500 text-sm">Configure your viral project</p>
            </div>

            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500">Video Concept</label>
                <textarea 
                  value={videoTitle}
                  onChange={(e) => setVideoTitle(e.target.value)}
                  placeholder="e.g. 'I Built a Secret Room...'"
                  rows={2}
                  className="w-full bg-slate-900/60 border border-white/10 rounded-2xl px-5 py-4 focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all resize-none text-sm leading-relaxed"
                />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500">Design Vibe</label>
                <div className="grid grid-cols-2 gap-2">
                   {vibes.map(v => (
                     <button 
                       key={v}
                       onClick={() => setVibe(v)}
                       className={`text-[10px] py-2 px-3 rounded-xl border transition-all ${vibe === v ? 'bg-blue-600 border-blue-500 text-white' : 'bg-slate-800/50 border-white/5 text-slate-400 hover:bg-slate-800'}`}
                     >
                       {v}
                     </button>
                   ))}
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500">Subject Headshot</label>
                  {headshot && !isEditing && !isCameraActive && (
                    <button onClick={() => setIsEditing(true)} className="text-[10px] font-bold text-blue-400 hover:text-blue-300">
                      Edit Filter
                    </button>
                  )}
                </div>
                
                <div className="relative rounded-2xl overflow-hidden aspect-video bg-slate-900 border-2 border-dashed border-white/5 group">
                  {isCameraActive ? (
                    <div className="relative w-full h-full">
                      <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover scale-x-[-1]" />
                      <div className="absolute inset-0 flex items-center justify-center gap-4 bg-black/20">
                         <button onClick={capturePhoto} className="w-12 h-12 rounded-full bg-white text-black flex items-center justify-center shadow-2xl hover:scale-110 transition-transform">
                            <i className="fa-solid fa-camera"></i>
                         </button>
                         <button onClick={stopCamera} className="w-12 h-12 rounded-full bg-red-500 text-white flex items-center justify-center shadow-2xl hover:scale-110 transition-transform">
                            <i className="fa-solid fa-xmark"></i>
                         </button>
                      </div>
                    </div>
                  ) : headshot ? (
                    <div className="relative w-full h-full">
                      <img src={headshot} alt="Ref" className="w-full h-full object-cover" />
                      {!isEditing && (
                        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4">
                          <button onClick={() => fileInputRef.current?.click()} className="p-3 bg-white/10 backdrop-blur-md rounded-xl text-white hover:bg-white/20 transition-colors">
                            <i className="fa-solid fa-upload"></i>
                          </button>
                          <button onClick={startCamera} className="p-3 bg-white/10 backdrop-blur-md rounded-xl text-white hover:bg-white/20 transition-colors">
                            <i className="fa-solid fa-camera"></i>
                          </button>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center space-y-4">
                       <div className="flex gap-4">
                          <button onClick={() => fileInputRef.current?.click()} className="w-12 h-12 rounded-2xl bg-slate-800 flex items-center justify-center text-slate-400 hover:text-white hover:bg-blue-600 transition-all">
                             <i className="fa-solid fa-upload"></i>
                          </button>
                          <button onClick={startCamera} className="w-12 h-12 rounded-2xl bg-slate-800 flex items-center justify-center text-slate-400 hover:text-white hover:bg-blue-600 transition-all">
                             <i className="fa-solid fa-camera"></i>
                          </button>
                       </div>
                       <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Select Reference</p>
                    </div>
                  )}
                  <canvas ref={canvasRef} className="hidden" />
                  <canvas ref={editCanvasRef} className="hidden" />
                </div>

                {/* Inline Image Editor Controls */}
                {isEditing && headshot && (
                  <div className="p-4 bg-white/5 rounded-2xl border border-white/5 space-y-4 animate-in slide-in-from-top-2">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[10px] font-black uppercase text-slate-500">Photo Processor</span>
                      <button onClick={() => setIsEditing(false)} className="text-[10px] font-bold text-slate-400 hover:text-white">Done</button>
                    </div>
                    <div className="space-y-4">
                      <div className="space-y-1">
                        <div className="flex justify-between text-[8px] font-black uppercase text-slate-500">
                          <span>Brightness</span>
                          <span>{brightness}%</span>
                        </div>
                        <input 
                          type="range" min="0" max="200" value={brightness} 
                          onChange={(e) => setBrightness(parseInt(e.target.value))}
                          className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500" 
                        />
                      </div>
                      <div className="space-y-1">
                        <div className="flex justify-between text-[8px] font-black uppercase text-slate-500">
                          <span>Contrast</span>
                          <span>{contrast}%</span>
                        </div>
                        <input 
                          type="range" min="0" max="200" value={contrast} 
                          onChange={(e) => setContrast(parseInt(e.target.value))}
                          className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500" 
                        />
                      </div>
                    </div>
                    <button 
                      onClick={() => { setBrightness(100); setContrast(100); }}
                      className="w-full py-1 text-[8px] font-black uppercase text-slate-500 hover:text-white transition-colors"
                    >
                      Reset Filters
                    </button>
                  </div>
                )}
                
                <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept="image/*" />
              </div>

              {error && (
                <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-4 rounded-2xl text-xs flex items-center gap-3 animate-in slide-in-from-top-2">
                  <i className="fa-solid fa-triangle-exclamation"></i>
                  {error}
                </div>
              )}

              <button 
                onClick={handleStartGeneration}
                disabled={status.startsWith('GENERATING') || !videoTitle || !headshot}
                className="w-full py-5 rounded-2xl font-black text-sm uppercase tracking-widest bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:opacity-90 active:scale-95 transition-all shadow-xl shadow-blue-500/20 disabled:opacity-30 disabled:grayscale"
              >
                {status.startsWith('GENERATING') ? (
                  <span className="flex items-center justify-center gap-3">
                    <i className="fa-solid fa-circle-notch fa-spin"></i>
                    Synthesizing...
                  </span>
                ) : "Construct Viral Pack"}
              </button>
            </div>
          </div>

          {result && (
            <div className="glass-effect rounded-3xl p-6 border-white/5 space-y-5 animate-in fade-in duration-700">
               <div className="flex items-center justify-between">
                  <h3 className="text-[10px] font-black uppercase tracking-widest text-slate-500">Live Simulator</h3>
                  <div className="text-green-400 font-black text-xs flex items-center gap-2">
                     <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                     {simViews.toLocaleString()} Views
                  </div>
               </div>
               {/* Majedar Roast Card */}
               <div className="p-4 bg-orange-500/10 rounded-2xl border border-orange-500/20 relative group overflow-hidden">
                  <div className="absolute top-0 right-0 p-2 opacity-20 group-hover:opacity-100 transition-opacity">
                    <i className="fa-solid fa-fire text-orange-500 text-2xl rotate-12"></i>
                  </div>
                  <div className="absolute -top-3 left-4 bg-orange-600 text-[8px] font-black text-white px-2 py-0.5 rounded uppercase tracking-widest flex items-center gap-1">
                    <i className="fa-solid fa-skull"></i>
                    Salty Producer says:
                  </div>
                  <p className="text-[11px] text-orange-200 italic leading-relaxed pt-2">
                    "{result.metadata.roast}"
                  </p>
               </div>
               <div className="flex items-center justify-between pt-2">
                  <div className="flex flex-col">
                    <span className="text-[9px] font-black text-blue-400 uppercase tracking-widest">Predicted CTR</span>
                    <span className="text-[8px] text-slate-500 font-medium">Confidence: High</span>
                  </div>
                  <div className={`text-2xl font-black ${result.metadata.predictedCTR > 10 ? 'text-green-400' : 'text-white'}`}>
                    {result.metadata.predictedCTR}%
                  </div>
               </div>
            </div>
          )}
        </div>

        {/* Right Output Display */}
        <div className="lg:col-span-8 space-y-8">
          {!result && status === AppStatus.IDLE && (
            <div className="h-[650px] glass-effect rounded-[3rem] border-dashed border-white/10 flex flex-col items-center justify-center text-center p-12 relative overflow-hidden group">
               <div className="absolute inset-0 bg-gradient-to-tr from-blue-500/5 via-transparent to-purple-500/5"></div>
               <div className="w-32 h-32 bg-slate-900 rounded-[2.5rem] flex items-center justify-center text-5xl mb-8 float-animation group-hover:scale-110 transition-transform">🎯</div>
               <h3 className="text-3xl font-bold mb-4">Studio Waiting...</h3>
               <p className="text-slate-500 max-w-sm text-lg font-light leading-relaxed">
                  Upload your headshot and give the AI a concept to start the "Viral Engine".
               </p>
            </div>
          )}

          {status.startsWith('GENERATING') && (
            <div className="space-y-8 animate-pulse">
              <div className="aspect-video bg-slate-900 rounded-[3rem] border border-white/5 flex items-center justify-center">
                 <div className="text-center space-y-6">
                    <div className="w-16 h-16 border-4 border-blue-500/20 border-t-blue-500 rounded-full animate-spin mx-auto"></div>
                    <div>
                      <p className="text-blue-500 font-black uppercase tracking-widest text-xs mb-2">{status.split('_').join(' ')}</p>
                      <p className="text-slate-500 text-sm">Processing Neural Design Layers...</p>
                    </div>
                 </div>
              </div>
              <div className="grid grid-cols-3 gap-6">
                {[1,2,3].map(i => <div key={i} className="h-28 bg-slate-900 rounded-[2rem] border border-white/5"></div>)}
              </div>
            </div>
          )}

          {result && (
            <div className="space-y-8 animate-in slide-in-from-bottom-12 duration-700">
              <div className="space-y-6">
                <div className="flex items-center justify-between px-4">
                  <div className="flex bg-slate-900 p-1.5 rounded-2xl border border-white/5">
                    <button onClick={() => setPreviewMode('canvas')} className={`px-6 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${previewMode === 'canvas' ? 'bg-blue-600 text-white shadow-xl' : 'text-slate-500 hover:text-white'}`}>Original</button>
                    <button onClick={() => setPreviewMode('feed')} className={`px-6 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${previewMode === 'feed' ? 'bg-blue-600 text-white shadow-xl' : 'text-slate-500 hover:text-white'}`}>Context</button>
                  </div>
                  <div className="flex gap-4">
                    {/* Download Button */}
                    <button 
                      onClick={handleDownload}
                      className="px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-lg hover:shadow-emerald-500/20 hover:scale-105 transition-all flex items-center gap-2"
                    >
                      <i className="fa-solid fa-download"></i>
                      Download
                    </button>
                    <button 
                      onClick={() => setShowHeatmap(!showHeatmap)} 
                      className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest border transition-all ${showHeatmap ? 'bg-orange-500/20 border-orange-500 text-orange-400' : 'bg-white/5 border-white/5 text-slate-400 hover:text-white'}`}
                    >
                      <i className="fa-solid fa-fire-flame-curved mr-2"></i> Heatmap
                    </button>
                    <button onClick={reset} className="p-2 text-slate-500 hover:text-red-400 transition-colors">
                      <i className="fa-solid fa-trash-can"></i>
                    </button>
                  </div>
                </div>

                <div className="relative rounded-[3rem] overflow-hidden border border-white/10 shadow-3xl bg-black">
                  {previewMode === 'canvas' ? (
                    <div className="relative w-full aspect-video group">
                      <img src={result.imageUrl} className="w-full h-full object-cover" alt="Result" />
                      
                      {/* Dynamic Saliency Heatmap Overlay */}
                      {showHeatmap && (
                        <>
                          <div className="absolute inset-0 pointer-events-none opacity-80 mix-blend-screen transition-all duration-500">
                             {/* Face Attention Node */}
                             <div 
                              className="absolute top-[25%] left-[20%] w-[35%] h-[45%] rounded-full animate-pulse"
                              style={{ 
                                ...getHeatmapStyles(getHeatmapBaseColor('core')),
                                animationDuration: '3s'
                              }}
                             ></div>
                             {/* Main Text Attention Node */}
                             <div 
                              className="absolute bottom-[10%] left-[10%] w-[60%] h-[20%] rounded-[50px] animate-pulse"
                              style={{ 
                                ...getHeatmapStyles(getHeatmapBaseColor('secondary')),
                                animationDuration: '4s',
                                animationDelay: '0.5s'
                              }}
                             ></div>
                             {/* Edge Visual Hook Attention Node */}
                             <div 
                              className="absolute top-[15%] right-[15%] w-[25%] h-[25%] rounded-full animate-pulse"
                              style={{ 
                                ...getHeatmapStyles(getHeatmapBaseColor('edge')),
                                animationDuration: '5s',
                                animationDelay: '1s'
                              }}
                             ></div>
                          </div>

                          {/* Heatmap Interactive Controls */}
                          <div className="absolute top-6 right-6 p-4 glass-effect rounded-2xl border border-white/10 space-y-4 animate-in slide-in-from-right-4 w-52 z-30 shadow-2xl">
                             <div className="space-y-1">
                                <label className="text-[8px] font-black uppercase text-slate-400 tracking-widest">Saliency Intensity</label>
                                <input 
                                  type="range" 
                                  min="10" 
                                  max="100" 
                                  value={heatmapIntensity}
                                  onChange={(e) => setHeatmapIntensity(parseInt(e.target.value))}
                                  className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-orange-500"
                                />
                             </div>
                             <div className="space-y-1">
                                <label className="text-[8px] font-black uppercase text-slate-400 tracking-widest">Color Mode</label>
                                <div className="flex gap-2">
                                  {(['classic', 'thermal', 'glitch'] as const).map(p => (
                                    <button 
                                      key={p}
                                      onClick={() => setHeatmapPreset(p)}
                                      className={`flex-1 py-1 rounded-md text-[8px] font-bold uppercase border transition-all ${heatmapPreset === p ? 'bg-orange-500 border-orange-400 text-white' : 'bg-slate-800 border-white/5 text-slate-500 hover:text-white'}`}
                                    >
                                      {p}
                                    </button>
                                  ))}
                                </div>
                             </div>
                             <button 
                              onClick={() => setShowHeatmap(false)}
                              className="w-full py-1 text-[8px] font-black uppercase text-slate-500 hover:text-white transition-colors border-t border-white/5 pt-2"
                             >
                               Close Heatmap
                             </button>
                          </div>
                        </>
                      )}
                    </div>
                  ) : (
                    <div className="bg-[#0f0f0f] w-full aspect-video p-10 flex items-center justify-center">
                      <div className="w-[320px] bg-black rounded-[3.5rem] p-4 border-[8px] border-slate-800 shadow-2xl h-[580px] relative overflow-hidden">
                        <div className="w-24 h-6 bg-black absolute top-0 left-1/2 -translate-x-1/2 rounded-b-2xl z-20"></div>
                        <div className="mt-8 space-y-6">
                          <div className="flex items-center justify-between px-4 text-[10px] text-white font-bold">
                            <span>12:00</span>
                            <div className="flex gap-1.5 items-center">
                              <i className="fa-solid fa-signal text-[8px]"></i>
                              <i className="fa-solid fa-wifi text-[8px]"></i>
                              <i className="fa-solid fa-battery-full text-[8px]"></i>
                            </div>
                          </div>
                          <div className="space-y-6 px-1">
                            <div className="space-y-3 opacity-30">
                              <div className="aspect-video bg-slate-800 rounded-2xl"></div>
                              <div className="flex gap-3">
                                <div className="w-10 h-10 rounded-full bg-slate-700"></div>
                                <div className="flex-1 space-y-1.5">
                                  <div className="h-4 bg-slate-700 w-full rounded"></div>
                                  <div className="h-3 bg-slate-700 w-1/2 rounded"></div>
                                </div>
                              </div>
                            </div>
                            <div className="space-y-3 relative">
                              <div className="relative">
                                <img src={result.imageUrl} className="aspect-video object-cover rounded-2xl ring-4 ring-blue-600/50 ring-offset-4 ring-offset-black" />
                                <div className="absolute bottom-2 right-2 bg-black/90 text-[10px] px-1.5 py-0.5 rounded font-bold text-white">14:22</div>
                              </div>
                              <div className="flex gap-3">
                                <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-blue-600 to-purple-600 flex items-center justify-center text-[10px] font-black text-white shadow-lg">ME</div>
                                <div className="flex-1 space-y-1">
                                  <div className="text-[13px] font-bold text-white leading-tight line-clamp-2">{result.metadata.viralTitles.curiosityGap}</div>
                                  <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
                                    <span>Your Channel</span>
                                    <i className="fa-solid fa-circle-check text-[8px] text-slate-500"></i>
                                    <span>• 2.4M views</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Enhanced Retention Strategy Card (Majedar Add-on) */}
              <div className="glass-effect rounded-[2.5rem] p-8 border-white/5 shadow-2xl relative overflow-hidden group">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-blue-600/10 blur-[60px] pointer-events-none group-hover:bg-blue-600/20 transition-all"></div>
                  <h3 className="text-xl font-black uppercase tracking-tighter mb-6 flex items-center gap-3">
                    <i className="fa-solid fa-clapperboard text-blue-500"></i>
                    The Director's Retention Blueprint
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {result.metadata.retentionBlueprint.map((step, i) => (
                      <div key={i} className="p-6 bg-white/5 rounded-2xl border border-white/5 flex flex-col gap-3 relative hover:bg-white/10 transition-all hover:scale-[1.02]">
                        <div className="absolute -top-3 -left-2 w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center font-black text-xs shadow-lg shadow-blue-500/20">
                          {i + 1}
                        </div>
                        <span className="text-[9px] font-black text-blue-400 uppercase tracking-widest mt-2">
                          {i === 0 ? "The Hook" : i === 1 ? "The Re-Hook" : "The Payoff Plan"}
                        </span>
                        <p className="text-xs font-medium leading-relaxed text-slate-300">
                          {step}
                        </p>
                      </div>
                    ))}
                  </div>
              </div>

              {/* Data Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="glass-effect rounded-[2.5rem] p-8 border-white/5 space-y-6 shadow-xl">
                  <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 flex items-center gap-3">
                    <i className="fa-solid fa-angles-right text-blue-500"></i>
                    A/B Titles
                  </h3>
                  <div className="space-y-4">
                    {(Object.entries(result.metadata.viralTitles) as [string, string][]).map(([key, val]) => (
                      <div key={key} className="p-5 bg-white/5 rounded-2xl border border-white/5 group hover:bg-white/10 transition-all flex items-start gap-4">
                        <div className="flex-1">
                          <span className="text-[9px] font-black text-blue-400 uppercase tracking-tighter block mb-1.5">{key.replace(/([A-Z])/g, ' $1')}</span>
                          <p className="text-sm font-semibold leading-relaxed text-slate-200">{val}</p>
                        </div>
                        <button onClick={() => handleCopy(val, `title-${key}`)} className={`p-2 rounded-lg transition-all ${copyStatus === `title-${key}` ? 'bg-green-500/20 text-green-400' : 'text-slate-500 hover:text-white hover:bg-white/5'}`}>
                          <i className={`fa-solid ${copyStatus === `title-${key}` ? 'fa-check' : 'fa-copy'}`}></i>
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-8">
                  <div className="glass-effect rounded-[2.5rem] p-8 border-white/5 space-y-6 shadow-xl">
                    <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 flex items-center gap-3">
                      <i className="fa-solid fa-link text-purple-500"></i>
                      Search Intelligence
                    </h3>
                    <div className="space-y-4">
                      {result.strategy?.searchSources.length ? result.strategy.searchSources.map((s, i) => (
                        <a key={i} href={s.uri} target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 p-4 bg-white/5 hover:bg-white/10 rounded-2xl border border-white/5 transition-all">
                          <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-[10px] text-blue-400"><i className="fa-solid fa-globe"></i></div>
                          <span className="text-xs font-bold text-slate-300 line-clamp-1 flex-1">{s.title}</span>
                          <i className="fa-solid fa-arrow-up-right-from-square text-[10px] text-slate-500"></i>
                        </a>
                      )) : <p className="text-xs text-slate-500 italic">No search sources found.</p>}
                    </div>
                  </div>

                  <div className="bg-gradient-to-br from-indigo-600/10 to-purple-600/10 rounded-[2.5rem] p-8 border border-white/5 text-center">
                    <h3 className="text-sm font-black text-white mb-4">Wanna try a different Vibe?</h3>
                    <button onClick={reset} className="px-8 py-3 bg-white text-black rounded-2xl text-[10px] font-black uppercase tracking-widest hover:scale-105 transition-all shadow-xl">Reset Engine</button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
};

export default App;
