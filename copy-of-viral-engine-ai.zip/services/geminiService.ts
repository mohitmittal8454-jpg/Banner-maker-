
import { GoogleGenAI, Type } from "@google/genai";
import { ThumbnailMetadata, StrategyInsight } from "../types";

const getAIClient = () => {
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

export const generateThumbnailImage = async (title: string, headshotBase64: string, vibe: string = "high-energy"): Promise<string> => {
  const ai = getAIClient();
  
  const prompt = `
    Act as a professional YouTube Graphic Designer. 
    Use the provided headshot as the main subject for a viral YouTube thumbnail.
    
    Topic: "${title}"
    Style Vibe: "${vibe}"
    
    Visual Style:
    - Subject: High-contrast, expressive facial expression, sharp focus.
    - Text: Huge, legible, high-impact sans-serif font with a bright outline or glow.
    - Background: High-quality, relevant to the topic, blurred slightly to emphasize the subject.
    - Color: High saturation, dramatic lighting, professional cinematic color grading.
    - Vibe: Intriguing, high-energy, "Click-bait" but high quality.
    
    Generate a 16:9 image.
  `;

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: 'image/jpeg',
            data: headshotBase64.split(',')[1] || headshotBase64
          }
        },
        { text: prompt }
      ]
    },
    config: {
      imageConfig: {
        aspectRatio: "16:9"
      }
    }
  });

  let imageUrl = "";
  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      imageUrl = `data:image/png;base64,${part.inlineData.data}`;
      break;
    }
  }

  if (!imageUrl) throw new Error("Thumbnail generation failed. No image part received.");
  return imageUrl;
};

export const generateMetadata = async (originalTitle: string, generatedImageUrl: string): Promise<ThumbnailMetadata> => {
  const ai = getAIClient();

  const prompt = `
    Analyze this generated thumbnail for the video "${originalTitle}". 
    Create viral YouTube metadata.
    
    Also, include:
    1. A "Roast": A funny, brutal, yet helpful piece of "tough love" advice about the concept (1-2 sentences).
    2. Predicted CTR: A realistic but optimistic percentage (e.g. 8.4).
    3. retentionBlueprint: A 3-step list of specific things the creator must say/do in the first 30 seconds to make the click worth it.
    
    JSON Output required.
  `;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: [
      {
        parts: [
          { inlineData: { mimeType: 'image/png', data: generatedImageUrl.split(',')[1] } },
          { text: prompt }
        ]
      }
    ],
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          viralTitles: {
            type: Type.OBJECT,
            properties: {
              curiosityGap: { type: Type.STRING },
              negativityBias: { type: Type.STRING },
              authority: { type: Type.STRING }
            },
            required: ["curiosityGap", "negativityBias", "authority"]
          },
          seoDescription: {
            type: Type.OBJECT,
            properties: {
              hook: { type: Type.STRING },
              valueProposition: { type: Type.STRING },
              tags: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ["hook", "valueProposition", "tags"]
          },
          pinnedComment: { type: Type.STRING },
          roast: { type: Type.STRING },
          predictedCTR: { type: Type.NUMBER },
          retentionBlueprint: { type: Type.ARRAY, items: { type: Type.STRING } }
        },
        required: ["viralTitles", "seoDescription", "pinnedComment", "roast", "predictedCTR", "retentionBlueprint"]
      }
    }
  });

  const text = response.text;
  if (!text) throw new Error("Metadata generation failed. No text response received.");
  return JSON.parse(text.trim());
};

export const generateStrategyInsight = async (title: string): Promise<StrategyInsight> => {
  const ai = getAIClient();
  
  const response = await ai.models.generateContent({
    model: "gemini-3-pro-preview",
    contents: `Analyze the current YouTube search trends and competition for the topic: "${title}". 
    Output format must be strictly JSON with fields: viralScore (number), trendAnalysis (string), competitorEdge (string).`,
    config: {
      tools: [{ googleSearch: {} }],
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          viralScore: { type: Type.NUMBER },
          trendAnalysis: { type: Type.STRING },
          competitorEdge: { type: Type.STRING }
        },
        required: ["viralScore", "trendAnalysis", "competitorEdge"]
      }
    },
  });

  const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map((chunk: any) => ({
    title: chunk.web?.title || "Search Source",
    uri: chunk.web?.uri || "#"
  })) || [];

  const text = response.text;
  if (!text) throw new Error("Strategy generation failed.");
  
  const data = JSON.parse(text.trim());
  return { ...data, searchSources: sources.slice(0, 3) };
};
