
export interface ThumbnailMetadata {
  viralTitles: {
    curiosityGap: string;
    negativityBias: string;
    authority: string;
  };
  seoDescription: {
    hook: string;
    valueProposition: string;
    tags: string[];
  };
  pinnedComment: string;
  roast: string; 
  predictedCTR: number;
  retentionBlueprint: string[]; // 3-step plan to keep viewers after they click
}

export interface StrategyInsight {
  viralScore: number;
  trendAnalysis: string;
  competitorEdge: string;
  searchSources: { title: string; uri: string }[];
}

export interface GenerationResult {
  imageUrl: string;
  metadata: ThumbnailMetadata;
  strategy?: StrategyInsight;
}

export enum AppStatus {
  IDLE = 'IDLE',
  GENERATING_IMAGE = 'GENERATING_IMAGE',
  GENERATING_METADATA = 'GENERATING_METADATA',
  GENERATING_STRATEGY = 'GENERATING_STRATEGY',
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR'
}
