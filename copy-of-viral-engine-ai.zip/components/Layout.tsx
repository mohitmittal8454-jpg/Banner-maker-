
import React from 'react';

interface LayoutProps {
  children: React.ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col relative overflow-hidden">
      {/* Background Orbs */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-600/10 rounded-full blur-[120px] pointer-events-none"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-purple-600/10 rounded-full blur-[120px] pointer-events-none"></div>

      <header className="sticky top-0 z-50 glass-effect border-b border-white/5 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-to-tr from-blue-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/20">
              <i className="fa-solid fa-play text-white text-lg"></i>
            </div>
            <h1 className="text-xl font-bold tracking-tight">
              AI<span className="text-blue-500">Thumbnails</span>Maker
            </h1>
          </div>
          <div className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-400">
            <a href="#" className="hover:text-white transition-colors">How it works</a>
            <a href="#" className="hover:text-white transition-colors">Pricing</a>
            <button className="bg-white/5 hover:bg-white/10 px-4 py-2 rounded-lg text-white transition-all border border-white/10">
              Community Designs
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 relative z-10 px-6 py-8">
        <div className="max-w-7xl mx-auto">
          {children}
        </div>
      </main>

      <footer className="py-8 px-6 border-t border-white/5 text-center text-slate-500 text-sm">
        <p>© 2024 AI Thumbnails Maker. Boost your CTR with Gemini AI.</p>
      </footer>
    </div>
  );
};
